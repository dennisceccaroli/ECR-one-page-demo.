#!/usr/bin/env python3
"""
ECR Demo — The Informational Energy Law
E_C = beta * (Phi**2) * K

How to run:
    python ecr_demo.py

This script:
  1) simulates coherence Phi in [0,1] and curvature-like K > 0
  2) generates informational energy E_C using a ground-truth beta with noise
  3) fits E_C ~ beta * (Phi^2 * K) via linear regression
  4) prints fitted beta and R^2
  5) plots the scatter and the fitted line

Reproducible: NumPy RNG is seeded.
Dependencies: numpy, matplotlib
"""
import numpy as np
import matplotlib.pyplot as plt

def simulate_data(n=300, seed=42, beta_true=1.7e-5, k_scale=100.0, noise_level=0.15):
    rng = np.random.default_rng(seed)
    # Coherence in [0,1]
    Phi = rng.random(n)
    # Curvature-like positive variable
    K = rng.gamma(shape=2.0, scale=k_scale, size=n)  # skewed positive distribution
    # Ground-truth informational energy
    X = (Phi**2) * K
    E_true = beta_true * X
    # Add proportional noise
    noise = rng.normal(loc=0.0, scale=noise_level * np.maximum(E_true.mean(), 1e-12), size=n)
    E_obs = E_true + noise
    return Phi, K, E_obs

def fit_beta(Phi, K, E):
    X = (Phi**2) * K
    # Linear regression through origin: E ≈ beta * X
    beta_hat = (X @ E) / (X @ X + 1e-12)
    # R^2 for model through origin
    y_hat = beta_hat * X
    ss_res = np.sum((E - y_hat)**2)
    ss_tot = np.sum((E - np.mean(E))**2)
    r2 = 1.0 - (ss_res / (ss_tot + 1e-12))
    return beta_hat, r2, X, y_hat

def main():
    Phi, K, E = simulate_data()
    beta_hat, r2, X, y_hat = fit_beta(Phi, K, E)

    print("=== ECR Demo Results ===")
    print(f"Fitted beta: {beta_hat:.6e}")
    print(f"R^2       : {r2:.3f}")
    print("Law tested: E_C ≈ beta * (Phi^2 * K)")
    print("Replicate by re-running; set your own seed / n in simulate_data().")

    # Plot scatter + fit line
    plt.figure(figsize=(7,5))
    plt.scatter(X, E, s=12, alpha=0.7, label="Simulated data")
    x_line = np.linspace(0, X.max(), 200)
    plt.plot(x_line, beta_hat * x_line, linewidth=2, label=f"Fit: E = {beta_hat:.2e}·X")
    plt.xlabel("X = Phi^2 · K")
    plt.ylabel("E_C (informational energy)")
    plt.title("E_C = beta · (Phi^2 · K) — ECR Demo")
    plt.legend()
    plt.tight_layout()
    plt.savefig("figure_fit.png", dpi=160)
    plt.show()

if __name__ == "__main__":
    main()
