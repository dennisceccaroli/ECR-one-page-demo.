# ECR One-Page Demo — *The Informational Energy Law*

**Law:** \( E_C = \beta\,\Phi^2\,K \) — informational energy grows with the **square of coherence** \(\Phi\) and with a curvature-like factor \(K\).

This repository provides a **fully reproducible** minimal demo (Python) and a **one-page PDF** explaining the idea.

---

## Quick start

```bash
pip install -r requirements.txt
python ecr_demo.py
```

You will see a scatter plot of \(E_C\) versus \(X = \Phi^2 K\) and a fitted line. The script prints the fitted \(\beta\) and the coefficient of determination (\(R^2\)).

---

## What this demonstrates

- A simple, testable law: **informational energy scales as coherence squared times curvature**.
- With synthetic but **controlled** data, the linear fit through the origin recovers \(\beta\) and a decent \(R^2\), showing the law is empirically checkable.
- You can swap the simulator with **your own data**: EEG bands, plasma diagnostics, or any coherent signal + curvature proxy.

---

## Citation & Context

- **Main reference / prior version:** Dennis Ceccaroli, *The Informational State of the Universe* — DOI: 10.5281/zenodo.17371512
- **This demo:** intended as a lightweight, reproducible touchstone. Please cite the DOI above and link back if you reuse.

---

## Files

- `ECR_demo.pdf` — one-page, Nature-style summary (title, abstract, figure, equation, replication steps).
- `ecr_demo.py` — minimal Python script to reproduce the law.
- `requirements.txt` — dependencies.
- `README.md` — this file.

---

*Last updated: 2025-10-17.*
